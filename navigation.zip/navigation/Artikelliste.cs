﻿namespace navigation
{
    internal class Artikelliste
    {
    }
}